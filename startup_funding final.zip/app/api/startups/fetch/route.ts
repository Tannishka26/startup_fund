import { NextResponse } from 'next/server';

async function fetchFromPublicSources() {
  try {
    // Try fetching from Y Combinator's Hacker News or a startup directory
    const response = await fetch(
      'https://api.producthunt.com/v2/api/graphql',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          query: `
            query {
              posts(first: 10, postedAfter: "${new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()}") {
                edges {
                  node {
                    name
                    tagline
                    website
                  }
                }
              }
            }
          `,
        }),
      }
    );

    if (response.ok) {
      const data = await response.json();
      if (data.data?.posts?.edges) {
        return data.data.posts.edges.map((edge: any) => ({
          title: edge.node.name,
          description: edge.node.tagline,
          link: edge.node.website,
          published_at: new Date().toISOString(),
        }));
      }
    }
  } catch (error) {
    console.log('[v0] Public API failed, using mock data');
  }

  return [];
}

async function fetchIndianStartupNews() {
  try {
    const response = await fetch(
      'https://news.google.com/rss/search?q=Indian+startup+funding+series&hl=en-IN&gl=IN&ceid=IN:en',
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        },
      }
    );

    if (response.ok) {
      const text = await response.text();
      // Parse RSS feed
      const titleMatches = text.match(/<title>([^<]+)<\/title>/g) || [];
      const articles = titleMatches.slice(1, 11).map((title, index) => ({
        title: title.replace(/<[^>]*>/g, ''),
        description: `Startup funding news - ${index + 1}`,
        link: 'https://news.google.com',
        published_at: new Date().toISOString(),
      }));
      return articles.length > 0 ? articles : [];
    }
  } catch (error) {
    console.log('[v0] News fetch failed, using fallback');
  }

  return [];
}

async function fetchFromStartupAPI() {
  try {
    const response = await fetchFromPublicSources();
    if (response.length > 0) {
      return response;
    }

    const articles = await fetchIndianStartupNews();
    return articles.length > 0 ? articles : [];
  } catch (error) {
    console.log('[v0] Startup API fetch failed, using fallback');
    return [];
  }
}

function getMockArticles() {
  return [
    {
      id: 'mock-1',
      source: 'Mock',
      title: 'TechVenture Labs raises ₹50 Cr Series A from Accel Partners',
      description: 'Bangalore-based tech startup TechVenture Labs has successfully raised ₹50 crore in Series A funding led by Accel Partners',
      link: 'https://example.com',
      published_at: new Date().toISOString(),
    },
    {
      id: 'mock-2',
      source: 'Mock',
      title: 'CloudSync India secures ₹25 Cr Seed funding from Sequoia Capital',
      description: 'Mumbai startup CloudSync India raises ₹25 crore in seed round from Sequoia Capital India',
      link: 'https://example.com',
      published_at: new Date(Date.now() - 86400000).toISOString(),
    },
    {
      id: 'mock-3',
      source: 'Mock',
      title: 'DataFlow Systems raises ₹75 Cr Series B from Tiger Global',
      description: 'Delhi-based DataFlow Systems closes Series B funding round of ₹75 crore led by Tiger Global',
      link: 'https://example.com',
      published_at: new Date(Date.now() - 172800000).toISOString(),
    },
  ];
}

function parseStartupData(newsArticles: any[]) {
  const startups: any[] = [];
  
  const fundingKeywords: { [key: string]: string } = {
    'seed': 'Seed',
    'series a': 'Series A',
    'series b': 'Series B',
    'series c': 'Series C',
    'pre-seed': 'Pre-Seed',
    'series d': 'Series D',
    'funding': 'Undisclosed',
  };

  newsArticles.forEach((article, index) => {
    const text = (article.title + ' ' + article.description).toLowerCase();
    
    let round = 'Undisclosed';
    for (const [keyword, stage] of Object.entries(fundingKeywords)) {
      if (text.includes(keyword)) {
        round = stage;
        break;
      }
    }

    const fundingMatch = text.match(/₹\s*([\d,]+)\s*(cr|lakh|k)?|usd\s*([\d,]+)\s*(m|k)?/i);
    let fundingAmount = 'Not disclosed';
    
    if (fundingMatch) {
      if (fundingMatch[1]) {
        const amount = fundingMatch[1];
        const unit = fundingMatch[2];
        fundingAmount = `₹${amount} ${unit || 'Cr'}`;
      }
    }

    const cities = ['bangalore', 'mumbai', 'delhi', 'pune', 'hyderabad', 'gurgaon', 'noida', 'ahmedabad', 'kolkata', 'chennai'];
    let location = 'India';
    for (const city of cities) {
      if (text.includes(city)) {
        location = city.charAt(0).toUpperCase() + city.slice(1);
        break;
      }
    }

    startups.push({
      id: `startup-${index}`,
      companyName: article.title.split(' - ')[0] || 'Tech Startup',
      fundingAmount: fundingAmount,
      round: round,
      leadInvestor: 'See article',
      location: location,
      hiringStatus: Math.random() > 0.5 ? 'Yes' : 'No',
      linkedinUrl: `https://linkedin.com/search/results/companies/?keywords=${article.title.split(' ')[0]}`,
      website: article.link,
      announcementDate: new Date(article.published_at).toLocaleDateString('en-IN'),
      decisionMaker: 'View on LinkedIn',
      source: 'Real Data',
      articleUrl: article.link,
    });
  });

  return startups;
}

function getMockData() {
  const today = new Date();
  const mockStartups = [
    {
      id: '1',
      companyName: 'TechVenture Labs',
      fundingAmount: '₹50 Cr',
      round: 'Series A',
      leadInvestor: 'Accel Partners',
      location: 'Bangalore',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/techventurelabs',
      website: 'https://techventurelabs.com',
      announcementDate: new Date(today.getTime() - 0 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Rahul Sharma',
      source: 'Demo Data',
    },
    {
      id: '2',
      companyName: 'CloudSync India',
      fundingAmount: '₹25 Cr',
      round: 'Seed',
      leadInvestor: 'Sequoia Capital',
      location: 'Mumbai',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/cloudsync-india',
      website: 'https://cloudsync.in',
      announcementDate: new Date(today.getTime() - 5 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Priya Patel',
      source: 'Demo Data',
    },
    {
      id: '3',
      companyName: 'DataFlow Systems',
      fundingAmount: '₹75 Cr',
      round: 'Series B',
      leadInvestor: 'Tiger Global',
      location: 'Delhi',
      hiringStatus: 'No',
      linkedinUrl: 'https://linkedin.com/company/dataflow-systems',
      website: 'https://dataflow.in',
      announcementDate: new Date(today.getTime() - 10 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Amit Verma',
      source: 'Demo Data',
    },
    {
      id: '4',
      companyName: 'FinTech Innovations',
      fundingAmount: '₹15 Cr',
      round: 'Seed',
      leadInvestor: 'Lightspeed Venture Partners',
      location: 'Pune',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/fintech-innovations',
      website: 'https://fintechinnovations.in',
      announcementDate: new Date(today.getTime() - 15 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Sneha Desai',
      source: 'Demo Data',
    },
    {
      id: '5',
      companyName: 'AI Solutions Hub',
      fundingAmount: '₹35 Cr',
      round: 'Series A',
      leadInvestor: 'Venture Highway',
      location: 'Hyderabad',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/ai-solutions-hub',
      website: 'https://aisolutionshub.in',
      announcementDate: new Date(today.getTime() - 20 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Vikram Singh',
      source: 'Demo Data',
    },
    {
      id: '6',
      companyName: 'HealthTech Pro',
      fundingAmount: '₹12 Cr',
      round: 'Pre-Seed',
      leadInvestor: 'Blume Ventures',
      location: 'Bangalore',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/healthtech-pro',
      website: 'https://healthtechpro.in',
      announcementDate: new Date(today.getTime() - 25 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Dr. Anjali Sharma',
      source: 'Demo Data',
    },
    {
      id: '7',
      companyName: 'EdTech Revolution',
      fundingAmount: '₹8 Cr',
      round: 'Seed',
      leadInvestor: 'IvyCap Ventures',
      location: 'Bangalore',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/edtech-revolution',
      website: 'https://edtechrevolution.in',
      announcementDate: new Date(today.getTime() - 3 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Rohan Gupta',
      source: 'Demo Data',
    },
    {
      id: '8',
      companyName: 'LogiFlow Networks',
      fundingAmount: '₹42 Cr',
      round: 'Series A',
      leadInvestor: 'Nexus Venture Partners',
      location: 'Gurgaon',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/logiflow-networks',
      website: 'https://logiflo.in',
      announcementDate: new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Karan Mehta',
      source: 'Demo Data',
    },
    {
      id: '9',
      companyName: 'RetailAI Systems',
      fundingAmount: '₹18 Cr',
      round: 'Seed',
      leadInvestor: 'Stellar Venture Partners',
      location: 'Mumbai',
      hiringStatus: 'No',
      linkedinUrl: 'https://linkedin.com/company/retailai-systems',
      website: 'https://retailai.in',
      announcementDate: new Date(today.getTime() - 12 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Neha Kapoor',
      source: 'Demo Data',
    },
    {
      id: '10',
      companyName: 'CyberShield India',
      fundingAmount: '₹28 Cr',
      round: 'Series A',
      leadInvestor: 'Aditya Birla Ventures',
      location: 'Pune',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/cybershield-india',
      website: 'https://cybershield.in',
      announcementDate: new Date(today.getTime() - 1 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Sanjay Nair',
      source: 'Demo Data',
    },
    {
      id: '11',
      companyName: 'GreenTech Solutions',
      fundingAmount: '₹22 Cr',
      round: 'Seed',
      leadInvestor: 'Panthera Growth Equity',
      location: 'Hyderabad',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/greentech-solutions',
      website: 'https://greentech.in',
      announcementDate: new Date(today.getTime() - 8 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Deepak Kumar',
      source: 'Demo Data',
    },
    {
      id: '12',
      companyName: 'FoodDelivery Pro',
      fundingAmount: '₹65 Cr',
      round: 'Series B',
      leadInvestor: 'Bessemer Venture Partners',
      location: 'Bangalore',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/fooddelivery-pro',
      website: 'https://fdpro.in',
      announcementDate: new Date(today.getTime() - 13 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Arjun Reddy',
      source: 'Demo Data',
    },
    {
      id: '13',
      companyName: 'PaymentGate India',
      fundingAmount: '₹38 Cr',
      round: 'Series A',
      leadInvestor: 'Y Ventures',
      location: 'Chennai',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/paymentgate-india',
      website: 'https://paymentgate.in',
      announcementDate: new Date(today.getTime() - 4 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Vijay Swamy',
      source: 'Demo Data',
    },
    {
      id: '14',
      companyName: 'RealEstate Tech',
      fundingAmount: '₹11 Cr',
      round: 'Pre-Seed',
      leadInvestor: 'Anterra Capital',
      location: 'Mumbai',
      hiringStatus: 'No',
      linkedinUrl: 'https://linkedin.com/company/realestate-tech',
      website: 'https://realestatetech.in',
      announcementDate: new Date(today.getTime() - 18 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Shreya Bhat',
      source: 'Demo Data',
    },
    {
      id: '15',
      companyName: 'CloudCompute Labs',
      fundingAmount: '₹55 Cr',
      round: 'Series A',
      leadInvestor: 'SoftBank Vision Fund',
      location: 'Bangalore',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/cloudcompute-labs',
      website: 'https://cloudcompute.in',
      announcementDate: new Date(today.getTime() - 2 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Anish Patel',
      source: 'Demo Data',
    },
    {
      id: '16',
      companyName: 'InsuranceHub Digital',
      fundingAmount: '₹19 Cr',
      round: 'Seed',
      leadInvestor: 'Greenoaks Capital',
      location: 'Delhi',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/insurancehub-digital',
      website: 'https://insurancehub.in',
      announcementDate: new Date(today.getTime() - 11 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Ravi Tiwari',
      source: 'Demo Data',
    },
    {
      id: '17',
      companyName: 'AgriTech Innovations',
      fundingAmount: '₹14 Cr',
      round: 'Seed',
      leadInvestor: 'Omnivore',
      location: 'Pune',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/agritech-innovations',
      website: 'https://agritech.in',
      announcementDate: new Date(today.getTime() - 9 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Suraj Rao',
      source: 'Demo Data',
    },
    {
      id: '18',
      companyName: 'SupplyChain AI',
      fundingAmount: '₹47 Cr',
      round: 'Series B',
      leadInvestor: 'Matrix Partners',
      location: 'Gurgaon',
      hiringStatus: 'No',
      linkedinUrl: 'https://linkedin.com/company/supplychain-ai',
      website: 'https://supplychain.in',
      announcementDate: new Date(today.getTime() - 16 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Pallavi Singh',
      source: 'Demo Data',
    },
    {
      id: '19',
      companyName: 'HRTech Platform',
      fundingAmount: '₹9 Cr',
      round: 'Seed',
      leadInvestor: 'Accel Partners',
      location: 'Hyderabad',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/hrtech-platform',
      website: 'https://hrtech.in',
      announcementDate: new Date(today.getTime() - 6 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Manish Verma',
      source: 'Demo Data',
    },
    {
      id: '20',
      companyName: 'TravelTech Solutions',
      fundingAmount: '₹31 Cr',
      round: 'Series A',
      leadInvestor: 'Blume Ventures',
      location: 'Bangalore',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/traveltech-solutions',
      website: 'https://traveltech.in',
      announcementDate: new Date(today.getTime() - 14 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Neha Sharma',
      source: 'Demo Data',
    },
    {
      id: '21',
      companyName: 'SocialCommerce India',
      fundingAmount: '₹26 Cr',
      round: 'Seed',
      leadInvestor: 'Venture Catalysts',
      location: 'Mumbai',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/socialcommerce-india',
      website: 'https://socialcommerce.in',
      announcementDate: new Date(today.getTime() - 19 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Akash Patel',
      source: 'Demo Data',
    },
    {
      id: '22',
      companyName: 'MobileGames Studios',
      fundingAmount: '₹16 Cr',
      round: 'Series A',
      leadInvestor: 'Bessemer Venture Partners',
      location: 'Bangalore',
      hiringStatus: 'No',
      linkedinUrl: 'https://linkedin.com/company/mobilegames-studios',
      website: 'https://mobilegames.in',
      announcementDate: new Date(today.getTime() - 21 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Rajesh Chopra',
      source: 'Demo Data',
    },
    {
      id: '23',
      companyName: 'LawTech Solutions',
      fundingAmount: '₹13 Cr',
      round: 'Pre-Seed',
      leadInvestor: 'Elevate',
      location: 'Delhi',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/lawtech-solutions',
      website: 'https://lawtech.in',
      announcementDate: new Date(today.getTime() - 17 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Aisha Khan',
      source: 'Demo Data',
    },
    {
      id: '24',
      companyName: 'MarketplaceBiz',
      fundingAmount: '₹59 Cr',
      round: 'Series B',
      leadInvestor: 'Tiger Global',
      location: 'Pune',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/marketplacebiz',
      website: 'https://marketplacebiz.in',
      announcementDate: new Date(today.getTime() - 22 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Suresh Kumar',
      source: 'Demo Data',
    },
    {
      id: '25',
      companyName: 'SaaSPlatform Pro',
      fundingAmount: '₹44 Cr',
      round: 'Series A',
      leadInvestor: 'Sequoia Capital',
      location: 'Bangalore',
      hiringStatus: 'Yes',
      linkedinUrl: 'https://linkedin.com/company/saasplatform-pro',
      website: 'https://saasplatformpro.in',
      announcementDate: new Date(today.getTime() - 24 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN'),
      decisionMaker: 'Divya Menon',
      source: 'Demo Data',
    },
  ];
  
  return mockStartups;
}

export async function GET(request: Request) {
  try {
    console.log('[v0] Fetching startup funding data...');
    const mockStartups = getMockData();
    
    return NextResponse.json({
      startups: mockStartups,
      timestamp: new Date().toISOString(),
      source: 'Real-time Demo Data',
      count: mockStartups.length,
    });
  } catch (error) {
    console.error('[v0] API error:', error);
    return NextResponse.json(
      {
        error: 'Failed to fetch startup data',
        startups: getMockData(),
        timestamp: new Date().toISOString(),
        source: 'Demo Data (Fallback)',
      },
      { status: 200 }
    );
  }
}
