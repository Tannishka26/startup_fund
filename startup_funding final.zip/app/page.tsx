'use client';

import { useEffect, useState } from 'react';
import DashboardLayout from '@/components/dashboard-layout';
import { AlertProvider } from '@/context/alert-context';

export default function Home() {
  const [startups, setStartups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStartups = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/startups/fetch');
        
        if (!response.ok) {
          throw new Error('Failed to fetch startup data');
        }
        
        const data = await response.json();
        setStartups(data.startups || []);
        setError(null);
      } catch (err) {
        console.error('[v0] Error fetching startups:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchStartups();
    // Refresh data every 5 minutes
    const interval = setInterval(fetchStartups, 5 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <AlertProvider>
      <DashboardLayout startups={startups} loading={loading} error={error} />
    </AlertProvider>
  );
}
