'use client';

import { useState } from 'react';
import Sidebar from './sidebar';
import Header from './header';
import HeroSection from './hero-section';
import DashboardContent from './dashboard-content';
import Analytics from './analytics';

export default function DashboardLayout({ startups, loading, error }) {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} startups={startups} />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <div className="flex-1 overflow-auto">
          {activeTab === 'overview' && (
            <>
              <HeroSection />
              <DashboardContent startups={startups} loading={loading} error={error} />
            </>
          )}
          {activeTab === 'alerts' && (
            <div className="p-8">
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900">Hiring Alerts</h1>
                <p className="text-gray-600 mt-2">Companies actively hiring with real-time job opportunities</p>
              </div>
              <DashboardContent startups={startups} loading={loading} error={error} hiringOnly={true} />
            </div>
          )}
          {activeTab === 'analytics' && (
            <Analytics startups={startups} />
          )}
        </div>
      </div>
    </div>
  );
}
