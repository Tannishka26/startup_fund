'use client';

import { useState } from 'react';

export default function DataTable({ startups }) {
  const [sortField, setSortField] = useState('announcementDate');
  const [sortOrder, setSortOrder] = useState('desc');
  const [hiringFilter, setHiringFilter] = useState('all');

  const handleSort = (field) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const filteredStartups = hiringFilter === 'all' 
    ? startups 
    : startups.filter(s => {
        if (hiringFilter === 'yes') return s.hiringStatus === 'Yes';
        if (hiringFilter === 'no') return s.hiringStatus === 'No';
        return true;
      });

  const sortedStartups = [...filteredStartups].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];

    if (typeof aVal === 'string') {
      return sortOrder === 'asc' 
        ? aVal.localeCompare(bVal)
        : bVal.localeCompare(aVal);
    }

    return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
  });

  const getRoundColor = (round) => {
    const colors: { [key: string]: string } = {
      'Seed': 'bg-blue-100 text-blue-800',
      'Pre-Seed': 'bg-cyan-100 text-cyan-800',
      'Series A': 'bg-purple-100 text-purple-800',
      'Series B': 'bg-indigo-100 text-indigo-800',
      'Series C': 'bg-violet-100 text-violet-800',
      'Series D': 'bg-rose-100 text-rose-800',
      'Undisclosed': 'bg-gray-100 text-gray-800',
    };
    return colors[round] || colors['Undisclosed'];
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 pb-4 border-b border-gray-200">
        <label className="text-sm font-medium text-gray-700">Filter by Hiring Status:</label>
        <select
          value={hiringFilter}
          onChange={(e) => setHiringFilter(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 hover:border-gray-400 transition"
        >
          <option value="all">All Companies</option>
          <option value="yes">Hiring (Yes)</option>
          <option value="no">Not Hiring (No)</option>
        </select>
        <span className="text-sm text-gray-600 ml-auto">
          Showing {sortedStartups.length} of {startups.length} startups
        </span>
      </div>

      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="w-full">
          <thead className="bg-gray-100 border-b border-gray-200">
            <tr>
              {['companyName', 'fundingAmount', 'round', 'leadInvestor', 'location', 'hiringStatus', 'linkedinUrl', 'announcementDate'].map((field) => (
                <th
                  key={field}
                  onClick={() => handleSort(field)}
                  className="px-6 py-3 text-left text-sm font-semibold text-gray-900 cursor-pointer hover:bg-gray-200 transition"
                >
                  <div className="flex items-center gap-2">
                    {field === 'companyName' && 'Company'}
                    {field === 'fundingAmount' && 'Funding'}
                    {field === 'round' && 'Round'}
                    {field === 'leadInvestor' && 'Lead Investor'}
                    {field === 'location' && 'Location'}
                    {field === 'hiringStatus' && 'Hiring'}
                    {field === 'linkedinUrl' && 'LinkedIn'}
                    {field === 'announcementDate' && 'Date'}
                    {sortField === field && (
                      <span className="text-xs">{sortOrder === 'asc' ? '↑' : '↓'}</span>
                    )}
                  </div>
                </th>
              ))}
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Action</th>
            </tr>
          </thead>
          <tbody>
            {sortedStartups.map((startup, idx) => (
              <tr
                key={startup.id}
                className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'} 
              >
                <td className="px-6 py-4 text-sm font-medium text-gray-900">{startup.companyName}</td>
                <td className="px-6 py-4 text-sm text-gray-600">{startup.fundingAmount}</td>
                <td className="px-6 py-4 text-sm">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getRoundColor(startup.round)}`}>
                    {startup.round}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">{startup.leadInvestor}</td>
                <td className="px-6 py-4 text-sm text-gray-600">{startup.location}</td>
                <td className="px-6 py-4 text-sm">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${startup.hiringStatus === 'Yes' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                    {startup.hiringStatus}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm">
                  <a href={startup.linkedinUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                    View Profile
                  </a>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">{startup.announcementDate}</td>
                <td className="px-6 py-4 text-sm">
                  <a href={startup.website} target="_blank" rel="noopener noreferrer" className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700 transition">
                    Visit
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
