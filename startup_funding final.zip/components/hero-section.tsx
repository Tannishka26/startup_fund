'use client';

export default function HeroSection() {
  return (
    <div className="mx-8 mt-8 mb-8 bg-gradient-to-r from-blue-600 via-blue-500 to-indigo-600 rounded-2xl p-12 text-white relative overflow-hidden shadow-lg">
      <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full -mr-40 -mt-40"></div>
      
      <div className="relative z-10">
        <div className="inline-block bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-semibold mb-4">
          Premium Intelligence
        </div>
        
        <h1 className="text-5xl font-bold mb-4 leading-tight max-w-2xl">
          Track Startup Funding in Real-Time
        </h1>
        
        <p className="text-lg text-white/90 mb-8 max-w-2xl">
          Discover newly funded Indian startups, identify hiring opportunities, access decision-maker contacts, and reach out to growing companies with precision.
        </p>
        
        <div className="flex gap-4">
          <button className="bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition shadow-lg">
            Explore Startups
          </button>
          <button className="border-2 border-white text-white px-8 py-3 rounded-full font-semibold hover:bg-white/10 transition">
            View Documentation
          </button>
        </div>
      </div>
    </div>
  );
}
