'use client';

export default function Sidebar({ activeTab, setActiveTab, startups = [] }) {
  const menuItems = [
    { id: 'overview', label: 'Overview', icon: 'home' },
    { id: 'alerts', label: 'Hiring Alerts', icon: 'bell' },
    { id: 'analytics', label: 'Analytics', icon: 'chart' },
  ];

  const getIcon = (iconName) => {
    switch(iconName) {
      case 'home':
        return <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-3m0 0l7-4 7 4M5 9v10a1 1 0 001 1h12a1 1 0 001-1V9m-9 11l4-4m0 0l4 4m-4-4v8" /></svg>;
      case 'bell':
        return <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>;
      case 'chart':
        return <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>;
      default:
        return null;
    }
  };

  const handleExport = () => {
    try {
      if (!startups || startups.length === 0) {
        alert('No data to export. Please wait for data to load.');
        return;
      }

      const headers = ['Company Name', 'Funding Amount', 'Round', 'Lead Investor', 'Location', 'Hiring Status', 'Announcement Date', 'Website', 'LinkedIn'];
      
      const rows = startups.map(startup => [
        startup.companyName || '',
        startup.fundingAmount || '',
        startup.round || '',
        startup.leadInvestor || '',
        startup.location || '',
        startup.hiringStatus || '',
        startup.announcementDate || '',
        startup.website || '',
        startup.linkedinUrl || '',
      ]);

      const csvContent = [
        headers.join(','),
        ...rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      ].join('\n');
      
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `startups-${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      console.log("[v0] Exported " + startups.length + " startups to CSV");
      alert(`Successfully exported ${startups.length} startups!`);
    } catch (error) {
      console.error("[v0] Export error:", error);
      alert('Error exporting data. Please try again.');
    }
  };

  return (
    <div className="w-64 bg-white border-r border-gray-200 p-6 overflow-y-auto shadow-sm">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">S</span>
          </div>
          <div>
            <h1 className="font-bold text-lg text-gray-900">StartupFund</h1>
            <p className="text-xs text-gray-500">Intelligence</p>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full text-left px-4 py-3 rounded-lg transition flex items-center gap-3 ${
              activeTab === item.id
                ? 'bg-blue-50 text-blue-900 font-semibold border border-blue-200'
                : 'text-gray-700 hover:bg-gray-50'
            }`}
          >
            {getIcon(item.icon)}
            {item.label}
          </button>
        ))}
      </div>

      <div className="mt-8 pt-8 border-t border-gray-200">
        <button 
          onClick={handleExport}
          className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-2 rounded-lg hover:opacity-90 transition font-semibold text-sm flex items-center justify-center gap-2"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19v-7m0 0V5m0 7H5m7 0h7" />
          </svg>
          Export Data
        </button>
      </div>
    </div>
  );
}
