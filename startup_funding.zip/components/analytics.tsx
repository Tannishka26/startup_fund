'use client';

import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function Analytics({ startups = [] }) {
  // Prepare data for charts
  const fundingByRound = startups.reduce((acc, startup) => {
    const existing = acc.find(item => item.round === startup.round);
    if (existing) {
      existing.count += 1;
      existing.amount += parseInt(startup.fundingAmount.replace(/[₹,]/g, '')) || 0;
    } else {
      acc.push({
        round: startup.round,
        count: 1,
        amount: parseInt(startup.fundingAmount.replace(/[₹,]/g, '')) || 0,
      });
    }
    return acc;
  }, []);

  const fundingByCity = startups.reduce((acc, startup) => {
    const existing = acc.find(item => item.city === startup.location);
    if (existing) {
      existing.count += 1;
      existing.amount += parseInt(startup.fundingAmount.replace(/[₹,]/g, '')) || 0;
    } else {
      acc.push({
        city: startup.location,
        count: 1,
        amount: parseInt(startup.fundingAmount.replace(/[₹,]/g, '')) || 0,
      });
    }
    return acc;
  }, []);

  const hiringStats = startups.reduce((acc, startup) => {
    const existing = acc.find(item => item.status === startup.hiringStatus);
    if (existing) {
      existing.value += 1;
    } else {
      acc.push({
        status: startup.hiringStatus,
        value: 1,
      });
    }
    return acc;
  }, []);

  const fundingTimeline = startups.slice(0, 10).map((startup, idx) => ({
    date: startup.announcementDate,
    company: startup.companyName.substring(0, 8),
    amount: parseInt(startup.fundingAmount.replace(/[₹,]/g, '')) || 0,
  }));

  const COLORS = ['#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#06b6d4'];

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Analytics Dashboard</h1>
        <p className="text-gray-600 mt-2">Real-time insights into startup funding trends and hiring patterns</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <p className="text-gray-600 text-sm font-medium">Total Startups</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{startups.length}</p>
          <p className="text-xs text-gray-500 mt-2">Last 30 days</p>
        </div>
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <p className="text-gray-600 text-sm font-medium">Total Funding</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">
            {(startups.reduce((sum, s) => sum + (parseInt(s.fundingAmount.replace(/[₹,]/g, '')) || 0), 0) / 100).toFixed(0)}Cr
          </p>
          <p className="text-xs text-gray-500 mt-2">Aggregated</p>
        </div>
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <p className="text-gray-600 text-sm font-medium">Hiring Companies</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">
            {startups.filter(s => s.hiringStatus === 'Yes').length}
          </p>
          <p className="text-xs text-gray-500 mt-2">Actively recruiting</p>
        </div>
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <p className="text-gray-600 text-sm font-medium">Avg Funding</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">
            ₹{(startups.reduce((sum, s) => sum + (parseInt(s.fundingAmount.replace(/[₹,]/g, '')) || 0), 0) / (startups.length || 1)).toFixed(0)}
          </p>
          <p className="text-xs text-gray-500 mt-2">Per startup</p>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-2 gap-6 mb-8">
        {/* Funding by Round */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Funding Distribution by Round</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={fundingByRound}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="round" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb' }} />
              <Bar dataKey="count" fill="#3b82f6" name="Companies" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Funding by City */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Funding by Location</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={fundingByCity}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="city" stroke="#6b7280" angle={-45} textAnchor="end" height={80} />
              <YAxis stroke="#6b7280" />
              <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb' }} />
              <Bar dataKey="amount" fill="#8b5cf6" name="Total Funding" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Second Row of Charts */}
      <div className="grid grid-cols-2 gap-6 mb-8">
        {/* Hiring Status */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Hiring Status Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={hiringStats} cx="50%" cy="50%" labelLine={false} label={({ status, value }) => `${status}: ${value}`} outerRadius={100} fill="#8884d8" dataKey="value">
                {hiringStats.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.status === 'Yes' ? '#10b981' : '#ef4444'} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Funding Timeline */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Funding Timeline</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={fundingTimeline}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="company" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb' }} />
              <Line type="monotone" dataKey="amount" stroke="#3b82f6" name="Funding Amount" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Round Distribution Pie Chart */}
      <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Round Distribution</h3>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie data={fundingByRound} cx="50%" cy="50%" labelLine={false} label={({ round, count }) => `${round}: ${count}`} outerRadius={100} fill="#8884d8" dataKey="count">
              {fundingByRound.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
