'use client';

import { useState } from 'react';

export default function Header() {
  const [showSettings, setShowSettings] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [emailAlerts, setEmailAlerts] = useState(false);

  const handleRefresh = () => {
    console.log("[v0] Refreshing data...");
    window.location.reload();
  };

  const handleSettingClick = (e) => {
    e.stopPropagation();
  };

  return (
    <div className="bg-white border-b border-gray-200 px-8 py-4 flex items-center justify-between shadow-sm">
      <h2 className="text-xl font-semibold text-gray-900">Startup Funding Detection</h2>
      
      <div className="flex items-center gap-6">
        <button 
          onClick={handleRefresh}
          title="Refresh data"
          className="p-2 hover:bg-gray-100 rounded-lg transition text-gray-700"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        </button>
        
        <div className="relative">
          <button 
            onClick={() => setShowSettings(!showSettings)}
            title="Settings"
            className="p-2 hover:bg-gray-100 rounded-lg transition text-gray-700"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </button>
          {showSettings && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
              <button 
                onClick={(e) => {
                  handleSettingClick(e);
                  setAutoRefresh(!autoRefresh);
                }}
                className="w-full text-left px-4 py-3 hover:bg-gray-50 text-gray-700 transition text-sm font-medium"
              >
                Auto-refresh: {autoRefresh ? 'On' : 'Off'}
              </button>
              <button 
                onClick={(e) => {
                  handleSettingClick(e);
                  setEmailAlerts(!emailAlerts);
                }}
                className="w-full text-left px-4 py-3 hover:bg-gray-50 text-gray-700 transition text-sm font-medium"
              >
                Email alerts: {emailAlerts ? 'On' : 'Off'}
              </button>
              <button 
                onClick={(e) => {
                  handleSettingClick(e);
                  alert('Preferences page coming soon!');
                  setShowSettings(false);
                }}
                className="w-full text-left px-4 py-3 hover:bg-gray-50 text-gray-700 border-t border-gray-200 transition text-sm font-medium"
              >
                Preferences
              </button>
            </div>
          )}
        </div>

        <div className="relative">
          <button 
            onClick={() => setShowNotifications(!showNotifications)}
            title="Notifications"
            className="p-2 hover:bg-gray-100 rounded-lg transition text-gray-700 relative"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
              <div className="p-4 border-b border-gray-200">
                <h3 className="font-semibold text-gray-900">Recent Alerts</h3>
              </div>
              <div className="max-h-64 overflow-y-auto">
                <div className="p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer">
                  <p className="text-sm font-semibold text-gray-900">TechVenture Labs hiring</p>
                  <p className="text-xs text-gray-500">2 roles open - Engineering, Sales</p>
                </div>
                <div className="p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer">
                  <p className="text-sm font-semibold text-gray-900">New Series A funding</p>
                  <p className="text-xs text-gray-500">CloudSync India raised ₹25 Cr</p>
                </div>
                <div className="p-4 hover:bg-gray-50 cursor-pointer">
                  <p className="text-sm font-semibold text-gray-900">InfoNexus opened hiring</p>
                  <p className="text-xs text-gray-500">5 positions across Product & Design</p>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-full hover:opacity-90 transition cursor-pointer"></div>
      </div>
    </div>
  );
}
